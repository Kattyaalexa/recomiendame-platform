-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 22-12-2010 a las 22:24:49
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `recomiendame`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `authors`
--

CREATE TABLE IF NOT EXISTS `authors` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Volcar la base de datos para la tabla `authors`
--

INSERT INTO `authors` (`id`, `name`) VALUES
(1, 'Eckhart Tolle'),
(2, 'Fernando Savater'),
(3, 'Fernando Calatrava'),
(8, 'a'),
(7, 'Cervantes'),
(9, 'car'),
(10, 'asd'),
(11, 's'),
(12, 'b');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `author_id` int(50) DEFAULT NULL,
  `description` text,
  `image` varchar(50) DEFAULT NULL,
  `created` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Volcar la base de datos para la tabla `books`
--

INSERT INTO `books` (`id`, `title`, `author_id`, `description`, `image`, `created`) VALUES
(18, 'El poder del ahora: una guía para la iluminación espiritual', 1, 'Para adentrarse en El Poder del Ahora tendremos que dejar atrás nuestra mente analítica y su falso yo, el ego. Desde la primera página de este extraordinario libro nos elevamos a una mayor altura y respiramos un aire más ligero. Conectamos con la esencia indestructible de nuestro Ser: "la Vida Una omnipresente, eterna, que está más allá de la mirada de formas de vida sujetas al nacimiento y a la muerte". Aunque el viaje es todo un reto, Eckhart Tolle nos guía usando un lenguaje simple y un sencillo formato de pregunta-respuesta. El Poder del Ahora, un fenómeno que se ha ido extendiendo de boca a boca desde que se publicó por primera vez, es uno de esos libros extraordinarios capaces de crear una experiencia tal en los lectores que puede cambiar radicalmente sus vidas para mejor.', 'b2cd6a3bbb5c8bb1d66f30b82ae4b755.jpg', '2010-12-22'),
(19, 'Las preguntas de la vida', 2, '«¿Para qué sirve la filosofía? Este libro quiere ser una iniciación elemental a la reflexión filosófica, tanto para uso de quienes se acercan por primera vez al estudio de la filosofía en el bachillerato como de aquellos otros que a cualquier edad aspiran a conocer los fundamentos de esta tradición intelectual.»', '6716107e6a588e41ad02e279c0e07789.jpg', '2010-12-22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `users`
--


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
